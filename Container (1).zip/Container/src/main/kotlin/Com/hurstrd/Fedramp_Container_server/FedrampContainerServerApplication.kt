package Com.hurstrd.Fedramp_Container_server

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class FedrampContainerServerApplication

fun main(args: Array<String>) {
	runApplication<FedrampContainerServerApplication>(*args)
}
