package Com.hurstrd.Fedramp_Container_server

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FedrampContainerServerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
