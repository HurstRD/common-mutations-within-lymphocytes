class PlotError(RuntimeError): pass
